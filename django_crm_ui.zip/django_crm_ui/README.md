# NEXA CRM — Django UI

`accounts/templates/` ichidagi HTML fayllarni Django `accounts/templates/` papkangizga, `accounts/static/css/style.css` faylini `accounts/static/css/` papkangizga ko‘chiring.

`settings.py` ichida `django.contrib.staticfiles` o‘rnatilganligiga va `STATIC_URL = 'static/'` belgilanganligiga ishonch hosil qiling.

URL nomlari: `home`, `login`, `register`, `logout`. HTML formalar `form` context obyektini kutadi. `home` sahifasini `@login_required` bilan himoyalang. `logout` POST orqali ishlashi kerak.

Bu dizayn UI to‘plami: dashboarddagi 0 raqamlari demo ko‘rsatkichlar, CRM CRUD backend modullari hali ulanmagan.
